package Fitness;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddMemberPage extends JFrame {
    private JTextField nameField;
    private JTextField idField;
    private JTextField emailField;
    private JTextField lockerNumField,classIDfield;
    private JComboBox<String> membershipTypeCombo;
    private JComboBox<String> scheduleCombo;
    private JTextField joinDateField;

    private Connection connection;

    public AddMemberPage(Connection connection) {
        this.connection = connection;

        setTitle("Add Member");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 2));

        JLabel idLabel = new JLabel("ID:");
        idField = new JTextField();

        JLabel nameLabel = new JLabel("Full Name:");
        nameField = new JTextField();

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();

        JLabel membershipTypeLabel = new JLabel("MembershipType:");
        String[] membershipTypes = {"regular 75$", "premium 100$"};
        membershipTypeCombo = new JComboBox<>(membershipTypes);

        JLabel joinDateLabel = new JLabel("JoinDate:");
        joinDateField = new JTextField();

        JLabel lockerNumLabel = new JLabel("LockerNum:");
        lockerNumField = new JTextField();

        JLabel scheduleLabel = new JLabel("Schedule:");
        String[] schedules = {"Mon, Wed, Fri - 5:00 am-8:00am", "Tues, Thurs, Saturday - 6:00 am"};
        scheduleCombo = new JComboBox<>(schedules);

        JLabel classIDLabel = new JLabel("classID:");
        classIDfield = new JTextField();


        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertMemberData();
                dispose();
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });


        panel.add(idLabel);
        panel.add(idField);

        panel.add(nameLabel);
        panel.add(nameField);

        panel.add(emailLabel);
        panel.add(emailField);

        panel.add(membershipTypeLabel);
        panel.add(membershipTypeCombo);

        panel.add(joinDateLabel);
        panel.add(joinDateField);

        panel.add(lockerNumLabel);
        panel.add(lockerNumField);

        panel.add(scheduleLabel);
        panel.add(scheduleCombo);

        panel.add(classIDLabel);
        panel.add(classIDfield);



        panel.add(okButton);
        panel.add(cancelButton);

        add(panel);
    }

    private void insertMemberData() {
        try {

            int memberId = Integer.parseInt(idField.getText());
            String Full_name = nameField.getText();
            String email = emailField.getText();
            int locker_num = Integer.parseInt(lockerNumField.getText());
            String membertype = (String) membershipTypeCombo.getSelectedItem();
            String schedule = (String) scheduleCombo.getSelectedItem();
            String joindate = joinDateField.getText();
            int classid = Integer.parseInt(classIDfield.getText());

            // Prepare the SQL query
            String query = "INSERT INTO member (memberID, Full_name, email, membertype, joindate, locker_num, schedule, classid) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);

            // Set parameters in the prepared statement
            statement.setInt(1, memberId);
            statement.setString(2, Full_name);
            statement.setString(3, email);
            statement.setString(4, membertype);
            statement.setString(5, joindate);
            statement.setInt(6, locker_num);
            statement.setString(7, schedule);
            statement.setInt(8, classid);

            // Execute the query
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Member added successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add member.");
            }

            // Close the statement
            statement.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error inserting member data: " + ex.getMessage());
        }
    }

}