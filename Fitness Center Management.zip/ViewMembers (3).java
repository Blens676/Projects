package Fitness;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewMembers extends JFrame {

    private Connection connection;

    public ViewMembers(Connection connection) {
        this.connection = connection;
        setTitle("View Members");
        setSize(500, 400);
        setLocationRelativeTo(null);

        displayAllMembers();
    }

    private void displayAllMembers() {
        try {
            String query = "SELECT * FROM member";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            JTable memberTable = new JTable(buildTableModel(resultSet));
            JScrollPane scrollPane = new JScrollPane(memberTable);

            getContentPane().add(scrollPane, BorderLayout.CENTER);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window on exit

            resultSet.close();
            statement.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Create column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int column = 1; column <= columnCount; column++) {
            columnNames[column - 1] = metaData.getColumnName(column);
        }

        // Create data array
        Object[][] data = new Object[100][columnCount]; // Assuming a maximum of 100 rows
        int rowCount = 0;
        while (resultSet.next() && rowCount < 100) {
            for (int column = 1; column <= columnCount; column++) {
                data[rowCount][column - 1] = resultSet.getObject(column);
            }
            rowCount++;
        }

        // Trim the data array to actual size
        Object[][] trimmedData = new Object[rowCount][columnCount];
        System.arraycopy(data, 0, trimmedData, 0, rowCount);

        return new DefaultTableModel(trimmedData, columnNames);
    }


}
