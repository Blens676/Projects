package Fitness;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteMember extends JFrame {

    private JPanel deletePanel;
    private JTextField memberIdField;
    private JButton deleteButton;
    private Connection connection; // Add a connection field

    public DeleteMember(Connection connection) {
        this.connection = connection;

        // Create the delete panel and set its properties
        deletePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        deletePanel.add(new JLabel("Member ID:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        memberIdField = new JTextField(15);
        deletePanel.add(memberIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteMember();
            }
        });
        deletePanel.add(deleteButton, gbc);

        // Set the layout and add the components to the frame
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        add(deletePanel, gbc);

        // Set the frame properties
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void deleteMember() {
        try {
            int memberIdToDelete = Integer.parseInt(memberIdField.getText());

            // Option 1: Set Foreign Key to NULL (If Nullable)
            String updateQuery = "UPDATE member SET classid = NULL WHERE memberID = ?";
            try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                updateStatement.setInt(1, memberIdToDelete);
                updateStatement.executeUpdate();
            }

            // Now you can delete the record from the member table
            String deleteQuery = "DELETE FROM member WHERE memberID = ?";
            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                deleteStatement.setInt(1, memberIdToDelete);
                int rowsAffected = deleteStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Member deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete member.");
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error deleting member data: " + ex.getMessage());
        }
    }

}
