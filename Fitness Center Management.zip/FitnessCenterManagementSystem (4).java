package Fitness;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class FitnessCenterManagementSystem extends JFrame implements ActionListener {

    Connection connection;
    public AddMemberPage addMemberPage;
    public UpdateMember updateMember;
    public DeleteMember deleteMember;
    public Instructor instructor;

    public MemberDetailsDisplay memberDetailsDisplay;

    private JButton viewMembersButton, registrarButton, instructorButton, addButton, updateButton, deleteButton;
    private JPanel welcomePanel, memberPanel, staffPanel;
    private JButton memberButton, staffButton, backButton,logbackButton, loginButton;
    private JLabel titleLabel, usernameLabel, passwordLabel, roleLabel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPanel currentPanel;

    public FitnessCenterManagementSystem() {
        super("FITNESS CENTER MANAGEMENT SYSTEM");

        viewMembersButton = new JButton("View Members");
        viewMembersButton.addActionListener(this);


        welcomePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        titleLabel = new JLabel("WELCOME TO FITNESS CENTER!", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLACK);
        welcomePanel.add(titleLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        memberButton = new JButton("Login as a member");
        memberButton.addActionListener(this);
        welcomePanel.add(memberButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        staffButton = new JButton("Login as staff");
        staffButton.addActionListener(this);
        welcomePanel.add(staffButton, gbc);


        memberPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        usernameLabel = new JLabel("Username:");
        memberPanel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        usernameField = new JTextField(15);
        memberPanel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        memberPanel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        passwordField = new JPasswordField(15);
        memberPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        logbackButton = new JButton("<<Back");
        logbackButton.addActionListener(this);
        memberPanel.add(logbackButton, gbc);


        gbc.gridx = 1;
        gbc.gridy = 2;
        loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        memberPanel.add(loginButton, gbc);
        memberPanel.setVisible(false);

        staffPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        roleLabel = new JLabel("Choose a role", SwingConstants.CENTER);
        roleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        roleLabel.setForeground(Color.BLUE);
        staffPanel.add(roleLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(this);
        staffPanel.add(registrarButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        instructorButton = new JButton("Instructor");
        instructorButton.addActionListener(this);
        staffPanel.add(instructorButton, gbc);
        staffPanel.setVisible(false);

        gbc.gridx = 0;
        gbc.gridy = 3;
        backButton = new JButton("<<Back");
        backButton.addActionListener(this);
        staffPanel.add(backButton, gbc);


        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        add(welcomePanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(memberPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(staffPanel, gbc);

        addButton = new JButton("Add");
        addButton.addActionListener(this);

        updateButton = new JButton("Update");
        updateButton.addActionListener(this);

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);


        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost/gym", "root", "Never2003$");
            memberDetailsDisplay = new MemberDetailsDisplay(this.connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == memberButton) {
            memberPanel.setVisible(true);
            welcomePanel.setVisible(false);
            currentPanel = memberPanel;


        } else if (e.getSource() == backButton) {
            currentPanel.setVisible(false);
            welcomePanel.setVisible(true);
            currentPanel = welcomePanel;
        } else if (e.getSource() == logbackButton) {
            currentPanel.setVisible(false);
            welcomePanel.setVisible(true);
            currentPanel = welcomePanel;

        }else if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            try {
                String query = "SELECT full_name, memberID FROM member WHERE full_name = ? AND memberID = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    memberDetailsDisplay.retrieveMemberDetailsFromDatabase(username, password);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password");
                }

                resultSet.close();
                statement.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        } else if (e.getSource() == staffButton) {
            // Show the staff panel and hide the welcome panel
            staffPanel.setVisible(true);
            welcomePanel.setVisible(false);
            currentPanel = staffPanel; // Update the current panel
        } else if (e.getSource() == registrarButton) {
            // Code for registrar login
            staffPanel.removeAll();
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.anchor = GridBagConstraints.CENTER;

            staffPanel.add(viewMembersButton, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            staffPanel.add(addButton, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            staffPanel.add(updateButton, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            staffPanel.add(deleteButton, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            staffPanel.add(backButton, gbc);



            staffPanel.revalidate();
            staffPanel.repaint();
        } else if (e.getSource() == instructorButton) {
            instructor = new Instructor(connection);
            instructor.setVisible(true);
        } else if (e.getSource() == addButton) {
            addMemberPage = new AddMemberPage(connection);
            addMemberPage.setVisible(true);
        } else if (e.getSource() == updateButton) {
            updateMember = new UpdateMember(connection);
            updateMember.setVisible(true);
        } else if (e.getSource() == deleteButton) {
            deleteMember = new DeleteMember(connection);
            deleteMember.setVisible(true);

        }
        else if (e.getSource() == viewMembersButton) {
            ViewMembers viewMembers = new ViewMembers(connection);
            viewMembers.setVisible(true);
        }

    }
    public static void main (String[] args){

        new FitnessCenterManagementSystem();
    }
}