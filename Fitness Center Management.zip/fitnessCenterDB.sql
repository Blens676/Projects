

CREATE DATABASE FitnessCenterDB;
USE FitnessCenterDB;

-- Create Member table
CREATE TABLE Member (
    memberID INT,
    contactinfo VARCHAR(255),
    membertype VARCHAR(100),
    joindate DATE,
    PRIMARY KEY (memberID)
);

-- Create Staff table
CREATE TABLE Staff (
    staffid INT PRIMARY KEY,
    name VARCHAR(255),
    role VARCHAR(255),
    contactinfo VARCHAR(255)
);


-- Create Class table
CREATE TABLE Class (
    classid INT PRIMARY KEY,
    classname VARCHAR(255),
    instructor VARCHAR(255),
    staffid INT,
    FOREIGN KEY (staffid) REFERENCES Staff(staffid)
);

-- Create Member_Class table
CREATE TABLE Member_Class (
    memberID INT,
    classid INT,
    amount DECIMAL(10, 2),
    paymentdate DATE,
    paymentmethod VARCHAR(100),
    PRIMARY KEY (memberID, classid),
    FOREIGN KEY (memberID) REFERENCES Member(memberID),
    FOREIGN KEY (classid) REFERENCES Class(classid)
);




-- Create Equipment table
CREATE TABLE Equipment (
    equipmentid INT PRIMARY KEY,
    equipmentname VARCHAR(255),
    quantity INT,
    purchasedate DATE
); 



-- Create Schedule table
CREATE TABLE Schedule (
    scheduleid INT PRIMARY KEY,
    classid INT,
    date DATE,
    time TIME,
    FOREIGN KEY (classid) REFERENCES Class(classid)
);

-- Populate the Member table
INSERT INTO Member (memberID, contactinfo, membertype, joindate) 
VALUES (1, 'john@example.com', 'Premium', '2023-01-15'),
       (2, 'jane@example.com', 'Standard', '2023-02-20'),
       (3, 'mike@example.com', 'Premium', '2023-03-10');
       
       -- Populate the Staff table
INSERT INTO Staff (staffid, name, role, contactinfo) 
VALUES (1, 'Trainer A', 'Fitness Trainer', 'trainerA@example.com'),
       (2, 'Trainer B', 'Yoga Instructor', 'trainerB@example.com'),
       (3, 'Trainer C', 'Pilates Instructor', 'trainerC@example.com');


-- Populate the Class table
INSERT INTO Class (classid, classname, instructor, staffid) 
VALUES (101, 'Yoga', 'Instructor A', 1),
       (102, 'Pilates', 'Instructor B', 2),
       (103, 'Zumba', 'Instructor C', 3);

-- Populate the Member-Class table
INSERT INTO Member_Class (memberid, classid, amount, paymentdate, paymentmethod) 
VALUES (1, 101, 50.00, '2023-01-20', 'Credit Card'),
       (2, 102, 40.00, '2023-02-25', 'PayPal'),
       (3, 103, 55.00, '2023-03-15', 'Credit Card');


-- Populate the Equipment table
INSERT INTO Equipment (equipmentid, equipmentname, quantity, purchasedate) 
VALUES (1, 'Treadmill', 5, '2022-12-01'),
       (2, 'Dumbbells', 20, '2023-01-10'),
       (3, 'Yoga Mats', 15, '2023-02-05');

-- Populate the Schedule table
INSERT INTO Schedule (scheduleid, classid, date, time) 
VALUES (201, 101, '2023-01-25', '10:00:00'),
       (202, 102, '2023-02-28', '09:00:00'),
       (203, 103, '2023-03-20', '18:00:00');
       
       
CREATE INDEX idx_instructor ON Class (instructor);
CREATE VIEW Member_Class_View AS
SELECT m.memberID, m.contactinfo, m.membertype, c.classid, c.classname, mc.amount, mc.paymentdate, mc.paymentmethod
FROM Member m
JOIN Member_Class mc ON m.memberID = mc.memberID
JOIN Class c ON c.classid = mc.classid;



