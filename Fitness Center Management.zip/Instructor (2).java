package Fitness;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Instructor extends JFrame implements ActionListener {

    private Connection connection;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public Instructor(Connection connection) {
        super("Instructor Login");
        this.connection = connection;

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(30, 30, 30, 30);
        gbc.anchor = GridBagConstraints.WEST;

        panel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        usernameField = new JTextField(15);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        passwordField = new JPasswordField(15);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        panel.add(loginButton, gbc);

        add(panel);

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Login")) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            try {
                String query = "SELECT staffID, name, role , email,memberID FROM staff WHERE name = ? AND staffID = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    String staffID = resultSet.getString("staffID");
                    String name = resultSet.getString("name");
                    String role= resultSet.getString("role");
                    String email= resultSet.getString("email");
                    String memberID= resultSet.getString("memberID");

                    String displayMessage = String.format(
                            "Login successful as %s\nStaff ID: %s\nrole: %s,\nemail: %s,\nmemberID: %s",
                            name, staffID, role,email,memberID
                    );

                    JOptionPane.showMessageDialog(this, displayMessage);
                    dispose(); // Close the login frame
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username or password");
                }

                resultSet.close();
                statement.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void showFrame() {
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
