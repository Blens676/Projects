package Fitness;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class UpdateMember extends JFrame implements ActionListener {
    Connection conn; // Make sure to initialize this variable

    JLabel l1, l2;
    JTextField t1, t2;
    JButton b1, b2;

    UpdateMember(Connection connection) { // Accept a Connection object as a parameter
        super("Update Member");
        this.conn = connection; // Assign the passed connection to the class variable
        setLocation(350, 200);
        setSize(400, 200);

        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3, 1, 10, 10));
        p.setBackground(Color.WHITE);

        l1 = new JLabel("Enter Member ID: ");
        l2 = new JLabel("Enter Member Name: ");
        t1 = new JTextField();
        t2 = new JTextField();
        b1 = new JButton("Next");
        b2 = new JButton("Cancel");

        p.add(l1);
        p.add(t1);
        p.add(l2);
        p.add(t2);
        p.add(b1);
        p.add(b2);
        setLayout(new BorderLayout());

        add(p, "Center");

        // For changing the color of the whole frame
        getContentPane().setBackground(Color.WHITE);

        b1.addActionListener(this);
        b2.addActionListener(this);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            String memberID = t1.getText(); // Get the entered ID
            String memberName = t2.getText(); // Get the entered name

            try {
                String query = "SELECT * FROM member WHERE memberID = '" + memberID + "' AND full_name = '" + memberName + "'";
                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet rs = statement.executeQuery();

                if (rs.next()) {
                    // Member found, show edit options
                    String[] options = {"Full Name", "Email", "Member Type", "Join Date", "Locker Number", "Schedule", "Class ID"};
                    String selectedOption = (String) JOptionPane.showInputDialog(null, "Select the field you want to edit:", "Edit Member", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

                    if (selectedOption != null) {
                        // User selected an option, proceed with the update
                        String newValue = JOptionPane.showInputDialog("Enter the new value for " + selectedOption + ":");
                        String updateColumn;

                        switch (selectedOption) {
                            case "Full Name":
                                updateColumn = "full_name";
                                break;
                            case "Email":
                                updateColumn = "email";
                                break;
                            case "Member Type":
                                updateColumn = "member_type";
                                break;
                            case "Join Date":
                                updateColumn = "join_date";
                                break;
                            case "Locker Number":
                                updateColumn = "locker_num";
                                break;
                            case "Schedule":
                                updateColumn = "schedule";
                                break;
                            case "Class ID":
                                updateColumn = "class_id";
                                break;
                            default:
                                updateColumn = null;
                        }

                        if (updateColumn != null) {
                            String updateQuery = "UPDATE member SET " + updateColumn + " = ? WHERE memberID = ?";
                            PreparedStatement pstmt = conn.prepareStatement(updateQuery);
                            pstmt.setString(1, newValue);
                            pstmt.setString(2, memberID);
                            int rowsUpdated = pstmt.executeUpdate();

                            if (rowsUpdated > 0) {
                                JOptionPane.showMessageDialog(null, "Member Updated");
                                this.setVisible(false);
                            } else {
                                JOptionPane.showMessageDialog(null, "Failed to update member");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid option selected");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Member not found");
                }

                statement.close(); // Close the PreparedStatement
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (ae.getSource() == b2) {
            this.setVisible(false);
        }
    }

}
