package Fitness;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Date;

// Member class to represent member details
public class Member {


        private int id;
        private String fullName;
        private String email;
        private String memberType;
        private Date joinDate;
        private int lockerNumber;
        private String schedule;
        private int classId;

        // Constructor
        public Member(int id, String fullName, String email, String memberType, Date joinDate, int lockerNumber, String schedule, int classId) {
            this.id = id;
            this.fullName = fullName;
            this.email = email;
            this.memberType = memberType;
            this.joinDate = joinDate;
            this.lockerNumber = lockerNumber;
            this.schedule = schedule;
            this.classId = classId;
        }

        public int getId() {
            return id;
        }

        public String getFullName() {
            return fullName;
        }

        public String getEmail() {
            return email;
        }

        public String getMemberType() {
            return memberType;
        }

        public Date getJoinDate() {
            return joinDate;
        }

        public int getLockerNumber() {
            return lockerNumber;
        }

        public String getSchedule() {
            return schedule;
        }

        public int getClassId() {
            return classId;
        }

        // Setters
        public void setId(int id) {
            this.id = id;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setMemberType(String memberType) {
            this.memberType = memberType;
        }

        public void setJoinDate(Date joinDate) {
            this.joinDate = joinDate;
        }

        public void setLockerNumber(int lockerNumber) {
            this.lockerNumber = lockerNumber;
        }

        public void setSchedule(String schedule) {
            this.schedule = schedule;
        }

        public void setClassId(int classId) {
            this.classId = classId;
        }

    }


    // MemberDetailsDisplay class to handle displaying member details
    class MemberDetailsDisplay {
        public Connection connection;

        public MemberDetailsDisplay(Connection connection) {
            this.connection=connection;
        }

        public static void displayMemberDetails(Member member) {
            JFrame memberDetailsFrame = new JFrame("Member Details");
            JPanel memberDetailsPanel = new JPanel(new GridLayout(8, 2));
            memberDetailsPanel.add(new JLabel("ID:"));
            memberDetailsPanel.add(new JLabel(String.valueOf(member.getId())));
            memberDetailsPanel.add(new JLabel("Full Name:"));
            memberDetailsPanel.add(new JLabel(member.getFullName()));
            memberDetailsPanel.add(new JLabel("Email:"));
            memberDetailsPanel.add(new JLabel(member.getEmail()));
            memberDetailsPanel.add(new JLabel("Member Type:"));
            memberDetailsPanel.add(new JLabel(member.getMemberType()));
            memberDetailsPanel.add(new JLabel("Join Date:"));
            memberDetailsPanel.add(new JLabel(String.valueOf(member.getJoinDate())));
            memberDetailsPanel.add(new JLabel("Locker Number:"));
            memberDetailsPanel.add(new JLabel(String.valueOf(member.getLockerNumber())));
            memberDetailsPanel.add(new JLabel("Schedule:"));
            memberDetailsPanel.add(new JLabel(member.getSchedule()));
            memberDetailsPanel.add(new JLabel("Class ID:"));
            memberDetailsPanel.add(new JLabel(String.valueOf(member.getClassId())));

            memberDetailsFrame.add(memberDetailsPanel);
            memberDetailsFrame.setSize(400, 300);
            memberDetailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            memberDetailsFrame.setLocationRelativeTo(null);
            memberDetailsFrame.setVisible(true);
        }

    public void retrieveMemberDetailsFromDatabase(String username, String password) {
            try {
                String query = "SELECT * FROM member WHERE Full_name = ? AND memberID = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, username);
                statement.setString(2, password);  // Using memberID as password
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    // Retrieve member details from the result set
                    int memberId = resultSet.getInt("memberID");
                    String full_name = resultSet.getString("full_name");
                    // Retrieve other member details from the result set
                    String email = resultSet.getString("email");
                    String memberType = resultSet.getString("membertype");
                    Date joinDate = resultSet.getDate("joindate");
                    int locker_Number = resultSet.getInt("locker_num");
                    String schedule = resultSet.getString("schedule");
                    int classId = resultSet.getInt("classID");

                    // Set the member variable with the retrieved data
                    Member member = new Member(memberId, full_name, email, memberType, joinDate, locker_Number, schedule, classId);

                    // Display member details or perform other operations
                    MemberDetailsDisplay.displayMemberDetails(member);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }




